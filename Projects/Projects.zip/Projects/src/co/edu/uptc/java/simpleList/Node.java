package co.edu.uptc.java.simpleList;

public class Node <T> {
    private T data;
    private Node<T> next;

    public Node(T data){
        this.data = data;
        next = null;
    }
    public T getValue(){
        return data;
    }

    public Node<T> getNext() {
        return next;
    }
    public void setNext(Node<T> next) {
        this.next = next;
    }
    
}
