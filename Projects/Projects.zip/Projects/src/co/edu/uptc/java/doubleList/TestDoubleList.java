package co.edu.uptc.java.doubleList;

import java.util.Arrays;

public class TestDoubleList {

    public static void main(String[] args) {

        DoubleList<String> lista = new DoubleList<>();

        System.out.println("¿Está vacía al inicio?: " + lista.isEmpty()); 

        //Agregar elemntos
        lista.add("Estructuras");
        lista.add("De");
        lista.add("Datos");
        lista.add("Dinámicas");
        lista.add("Java");

        System.out.println("Tamaño actual de la lista: " + lista.size());
        //get
        System.out.println("\n get(index)");
        System.out.println("Índice 0: " + lista.get(0)); 
        System.out.println("Índice 4: " + lista.get(4)); 
        System.out.println("Índice 2: " + lista.get(2)); 

        // Contains
        System.out.println("\ncontains ");
        System.out.println("¿Contiene 'Datos'?: " + lista.contains("Datos")); 
        System.out.println("¿Contiene 'C#'?: " + lista.contains("C#"));

        // toArray
        System.out.println("\nConvertir lista a Array de Objetos ");
        Object[] array = lista.toArray();
        System.out.println("Contenido del array: " + Arrays.toString(array));

        // Eliminar
        System.out.println("\n Eliminar");
        System.out.println("Eliminar 'Estructuras' (Head): " + lista.remove("Estructuras"));
        System.out.println("Eliminar 'Java' (Tail): " + lista.remove("Java"));
        System.out.println("Eliminar 'Datos' (Nodo intermedio): " + lista.remove("Datos"));

        System.out.println("\nTamaño final de la lista: " + lista.size()); 
    }
}
