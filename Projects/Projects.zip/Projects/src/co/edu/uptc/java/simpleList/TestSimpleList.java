package co.edu.uptc.java.simpleList;

public class TestSimpleList {
    public static void main(String[] args) {

        SimpleList<String> lista = new SimpleList<>();
        
        System.out.println("¿La lista está vacía al inicio?: " + lista.isEmpty());

        //  add()
        lista.add("Manzana");
        lista.add("Pera");
        lista.add("Banano");
        lista.add("Naranja");

        System.out.println("¿Está vacía?: " + lista.isEmpty());
        System.out.println("Tamaño actual: " + lista.size());

        // 3. Probar get(index)
        System.out.println("\n--- Probando método get(index) ---");
        System.out.println("Índice 0 (Cabeza): " + lista.get(0)); // Esperado: Manzana
        System.out.println("Índice 2 (Medio): " + lista.get(2));  // Esperado: Banano
        System.out.println("Índice 3 (Final): " + lista.get(3));  // Esperado: Naranja
        System.out.println("Índice inválido (4): " + lista.get(4)); // Esperado: null

        // 4. Probar contains(Object o)
        System.out.println("\n--- Probando método contains ---");
        System.out.println("¿Contiene 'Pera'?: " + lista.contains("Pera"));   // Esperado: true
        System.out.println("¿Contiene 'Uva'?: " + lista.contains("Uva"));     // Esperado: false

        // 5. Probar remove(Object o) y sus casos de frontera
        System.out.println("\n--- Probando método remove ---");
        
        // Caso A: Eliminar la Cabeza
        System.out.println("Eliminar 'Manzana' (Cabeza): " + lista.remove("Manzana")); // Esperado: true
        System.out.println("Nueva cabeza (índice 0): " + lista.get(0)); // Esperado: Pera

        // Caso B: Eliminar un elemento intermedio
        System.out.println("Eliminar 'Banano' (Medio): " + lista.remove("Banano")); // Esperado: true
        
        // Caso C: Intentar eliminar algo que no existe
        System.out.println("Eliminar 'Uva' (No existe): " + lista.remove("Uva")); // Esperado: false

        // 6. Estado Final
        System.out.println("\n--- Estado Final de la Lista ---");
        System.out.println("Tamaño final: " + lista.size()); // Esperado: 2
        System.out.println("Elementos restantes:");
        for (int i = 0; i < lista.size(); i++) {
            System.out.println(" -> Índice " + i + ": " + lista.get(i));
        }

        System.out.println("\n=== TEST FINALIZADO ===");
    }
}