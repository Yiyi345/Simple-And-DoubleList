package co.edu.uptc.java.doubleList;

public class DoubleList<T> {
    private NodeDoubleList<T> head;
    private NodeDoubleList<T> tail;
    private int size;

    public DoubleList() {
        head = null;
        tail = null;
        size = 0;
    }

    public int size() {
        if (size == Integer.MAX_VALUE) {
            return Integer.MAX_VALUE;
        }
        return size;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public boolean contains(Object o) {
        if (o == null) {
            throw new NullPointerException("La lista no permite datos nulos");
        }
        NodeDoubleList<T> auxNode = head;
        while (auxNode != null) {
            if (auxNode.getValue().equals(o)) {
                return true;
            }
            auxNode = auxNode.getNext();
        }
        return false;
    }

    public Object[] toArray() {
        if (isEmpty()) {
            return new Object[0];
        }
        int size = size();
        Object[] array = new Object[size];

        NodeDoubleList<T> current = head;
        int index = 0;

        while (current != null) {
            array[index] = current.getValue();
            current = current.getNext();
            index++;
        }
        return array;
    }

    public boolean add(T e) {
        NodeDoubleList<T> newNode = new NodeDoubleList<>(e);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.setNext(newNode);
            newNode.setPrevious(tail);
            tail = newNode;
        }
        size++;
        return true;
    }

    public boolean remove(Object o) {
        NodeDoubleList<T> aux = head;
        if (head == null) {
            return false;
        }
        while (aux != null) {
            if (aux.getValue().equals(o)) {
                if (aux == head && head.getNext() == null) {
                    head = null;
                    tail = null;
                } else if (aux == head) {
                    head = head.getNext();
                    head.setPrevious(null);
                } else if (aux == tail) {
                    tail = tail.getPrevious();
                    tail.setNext(null);
                } else {
                    aux.getPrevious().setNext(aux.getNext());
                    aux.getNext().setPrevious(aux.getPrevious());
                }
                size--;
                return true;
            }
            aux = aux.getNext();
        }
        return false;
    }

    public T get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Índice fuera de rango: " + index);
        }
        
        NodeDoubleList<T> aux;
        if (index < (size / 2)) {
            aux = head;
            for (int i = 0; i < index; i++) {
                aux = aux.getNext();
            }
        } 
        else {
            aux = tail;
            for (int i = size - 1; i > index; i--) {
                aux = aux.getPrevious();
            }
        }
        return aux.getValue();
    }
}